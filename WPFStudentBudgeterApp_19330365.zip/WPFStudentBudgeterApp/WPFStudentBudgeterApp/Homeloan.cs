﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WPFStudentBudgeterApp
{
    class Homeloan
    {
        //Connect budgetCalculation class library
        Formula formula = new Formula();
        //To add to the forms information
        public void setIncome(string Income)
        {
            formula.setIncome(Income);
        }
        public void addExpenses(string MonthlyTax, string Groceries, string WaterLights, string Travel, string Phone, string OtherExp)
        {
            formula.addExpenses(MonthlyTax, Groceries, WaterLights, Travel, Phone, OtherExp);
        }
        public void addBuyingProperty(string PropertyPrice, string Deposit, string Interest, string NumberOfMonths)
        {
            formula.addBuyingProperty(PropertyPrice, Deposit, Interest, NumberOfMonths);
        }
        public void addRent(string Rent)
        {
            formula.addRent(Rent);
        }
        public void addVehicle(string Model, string VehiclePrice, string VehicleDeposit, string VehicleInterest, string Premium)
        {
            formula.addVehicle(Model, VehiclePrice, VehicleDeposit, VehicleInterest, Premium);
        }

        //The Display for the end of the process
        public void BuyingDisplay()
        {
            //turned if statement to comments*************************************************

            //if (formula.HomeLoanRepayment() <= formula.MonthlyIncome() / 3)
            //{
            double amountRemaining = formula.MonthlyIncome() - Convert.ToDouble(formula.HomeLoanRepayment());
            String display = "";//Empty Variable
                                //Display Format
            display = formula.BuyingPropertyDisplay() + "Expenses: \n" + formula.DisplayExpenses() + "\n"
            + "Home Payment per Month: " + formula.HomeLoanRepayment().ToString() + "\n"
            + "Monthly Amount Remaining: " + amountRemaining.ToString()
            + "\n-------------------------------------------------------------";
            //MessageBox Display
            MessageBox.Show(display);
            //}

        }

        public void BuyingWithVehDisplay()
        {
            double amountRemaining = formula.MonthlyIncome() - formula.HomeLoanRepayment() - formula.vehicleMonthlyPayment();
            string display = "";
            display = formula.BuyingPropertyDisplay() +
                formula.DisplayExpenses() +
                "\nHome Payment per Month: " + formula.HomeLoanRepayment().ToString() +
                "\n" + formula.BuyingVehicleDisplay() +
                "\nMonthly Vehicle Payment: " + formula.vehicleMonthlyPayment().ToString() +
                "\nMonthly Amount Remaining: " + amountRemaining.ToString();
            //MessageBox Display
            MessageBox.Show(display);

        }

        //To display if the user has selected Renting instead of buying
        public void RentingDisplay()
        {
            double amountRemaining = formula.MonthlyIncome() - Convert.ToDouble(formula.getRent());
            String display = "";//Empty Variable
            //Display Format
            display = "Expenses\n" + "-------------------------------------------------------------" + formula.DisplayExpenses()
                + "\n-------------------------------------------------------------"
                + "\nMonthly Rental Amount: " + formula.getRent().ToString()
                + "\nYour Monthly Amount Remaining: " + amountRemaining.ToString()
                + "\n-------------------------------------------------------------";
            //MessageBox Display
            MessageBox.Show(display);

        }
        public void RentingWithVehDisplay()
        {
            double amountRemaining = formula.MonthlyIncome() - Convert.ToDouble(formula.getRent()) - formula.vehicleMonthlyPayment();
            String display = "";
            display = "Expenses\n" + "-------------------------------------------------------------\n" +
                formula.DisplayExpenses() +
                "\n-------------------------------------------------------------" +
                "\nMonthly Rental Amount: " + formula.getRent().ToString() + "\n" +
                formula.BuyingVehicleDisplay() +
                "\nMonthly Vehicle Payment: " + formula.vehicleMonthlyPayment().ToString() +
                "\nMonthly Amount Remaining: " + amountRemaining.ToString();
            MessageBox.Show(display);

        }
    }
}
    

