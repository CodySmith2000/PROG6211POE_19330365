﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFStudentBudgeterApp
{
    class Formula
    {
        //Declaring variables
        string Income, Rent;
        private int x = 0; //Expenses
        private int y = 0; //BuyingProperty
        private int z = 0; //Vehicle

        //List<T>
        //Creating List objects
        List<string> Expenses = new List<string>();
        List<string> BuyingProperty = new List<string>();
        List<string> Vehicle = new List<string>();

        //Set the income amount
        public void setIncome(string Income)
        {
            this.Income = Income;
        }


        //Add the elements to the Expense List using add() method
        //https://www.tutorialsteacher.com/csharp/csharp-list
        public void addExpenses(string MonthlyTax, string Groceries, string WaterLights, string Travel, string Phone, string OtherExp)
        {
            Expenses.Add(MonthlyTax);
            Expenses.Add(Groceries);
            Expenses.Add(WaterLights);
            Expenses.Add(Travel);
            Expenses.Add(Phone);
            Expenses.Add(OtherExp);
        }
        //Add the elements to the buy property to list
        public void addBuyingProperty(string PropertyPrice, string Deposit, string Interest, string NumberOfMonths)
        {
            BuyingProperty.Add(PropertyPrice);
            BuyingProperty.Add(Deposit);
            BuyingProperty.Add(Interest);
            BuyingProperty.Add(NumberOfMonths);
        }
        //Add elements to the buy vehicle list
        public void addVehicle(string Model, string VehiclePrice, string VehicleDeposit, string VehicleInterest, string Premium)
        {
            Vehicle.Add(Model);
            Vehicle.Add(VehiclePrice);
            Vehicle.Add(VehicleDeposit);
            Vehicle.Add(VehicleInterest);
            Vehicle.Add(Premium);

        }

        //return the rent amount
        public string getRent()
        {
            return Rent;
        }
        //Set the rent amount
        public void addRent(string Rent)
        {
            this.Rent = Rent;
        }

        //Calculate the Monthly Income
        //https://www.w3schools.com/cs/cs_while_loop.asp
        //
        //While Loop
        //https://www.w3schools.com/cs/cs_while_loop.asp
        public double MonthlyIncome()
        {
            x = Expenses.Count - 6;
            double monthlyIncome = Convert.ToDouble(Income);

            while (x < Expenses.Count)//While the app is still reading through the expenses
            {
                monthlyIncome -= Convert.ToDouble(Expenses[x]);
                x += 1;

            }
            return monthlyIncome;
        }

        //Calculate monthly payment of buying a home
        //https://www.siyavula.com/read/maths/grade-10/finance-and-growth/09-finance-and-growth-03
        public double HomeLoanRepayment()
        {
            y = BuyingProperty.Count - 4;
            double price = Convert.ToDouble(BuyingProperty[y]);//PropertyPrice
            double depositAmount = Convert.ToDouble(BuyingProperty[y + 1]);//Deposit
            double interestRate = Convert.ToDouble(BuyingProperty[y + 2]);//Interest %
            double months = Convert.ToDouble(BuyingProperty[y + 3]);// NumberOfMonths

            double p = price - depositAmount;
            double i = interestRate * 0.01;
            double n = months / 12; // to convert to years
            double monthlyPayment = p * (1 + i * n); // A=P(1+rn)

            return Math.Round(monthlyPayment, 2);//Rounded off to 2 double places

        }

        //Calculate Vehicle Monthly payment
        //Below i make use of Math.Pow() function which returns the base to the exponent power
        public double vehicleMonthlyPayment()
        {
            
            double vehPrice = Convert.ToDouble(Vehicle[z + 1]);//VehiclePrice
            double vehDeposit = Convert.ToDouble(Vehicle[z + 2]);//VehicleDeposit
            double vehInterest = Convert.ToDouble(Vehicle[z + 3]) / 100 / 12;//VehicleInterest 
            double vehPremium = Convert.ToDouble(Vehicle[z + 4]);//Premium

            double vehPayment = (vehPrice - vehDeposit) * (vehInterest * Math.Pow((1 + vehInterest), 60 / Math.Pow((1 + vehInterest), 60) - 1));

            vehPayment += vehPremium;
            vehPayment = Math.Round(vehPayment, 2);
            return vehPayment;
        }

        //build display if the user is buying property
        public String BuyingPropertyDisplay()
        {
            String Display = "";//****NOTE-----MADE String into string------------*********************************************
            double monthlyIncome = MonthlyIncome();
            double monthlyPayment = HomeLoanRepayment();


            if (monthlyIncome / 3 < monthlyPayment)
            {
                Display += "You are unlikely to get a home loan\n";
            }
            else if (monthlyIncome / 3 > monthlyPayment)
            {
                Display += "You are likely to get a home loan!\n";
            }
            return Display;
        }
        //building the display format for the expenses
        public String DisplayExpenses()
        {
            x = Expenses.Count - 6;
            string stDisplay = "";
            stDisplay = "\nIncome: " + Income.ToString() + "\nMonthly Tax: " + Expenses[x].ToString() +
                "\n-------------------------------------------------------------" +
                "\nGroceries: " + Expenses[x + 1] + "\nWater And Lights: " + Expenses[x + 2].ToString() +
                "\nTravel: " + Expenses[x + 3] + "\nCell and Telephone: " + Expenses[x + 4].ToString() +
                "\nOther Expenses: " + Expenses[x + 5].ToString();
            return stDisplay;
        }

        public String BuyingVehicleDisplay()
        {
            
            string stDisplay = "";
            stDisplay = "\nModel and make: " + Vehicle[z + 0] +
                "\nVehicle Price: " + Vehicle[z + 1] +
                "\nDeposit: " + Vehicle[z + 2] +
                "\nInterest: " + Vehicle[z + 3] +
                "\nPremium: " + Vehicle[z + 4];

            return stDisplay;
        }




    }
}

