﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFStudentBudgeterApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Homeloan homeloan = new Homeloan();
        double input;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)
        {
            //Applying users input 
            string GrossMonthlyIncome = this.txtGrossMonthlyIncome.Text;
            string EstimatedMonthlyTax = this.txtEstimatedTax.Text;

            //Applying users input for expenses
            string Groceries = this.txtGroceries.Text;
            string WaterAndLights = this.txtWaterLights.Text;
            string Travel = this.txtTravel.Text;
            string Phone = this.txtPhone.Text;
            string OtherExpenses = this.txtOther.Text;

            //Applying users input for buying a house
            string PropertyPrice = this.txtPropertyPrice.Text;
            string TotalDeposit = this.txtTotalDeposit.Text;
            string InterestRate = this.txtInterestRate.Text;
            string NumberOfMonths = this.txtNumberOfMonths.Text;

            //Applying users input for renting a house
            string RentalAmount = this.txtRentalAmount.Text;

            //Applying users input for a vehicle
            string vehicleModel = this.txtModelMake.Text;
            string VehiclePrice = this.txtVehiclePrice.Text;
            string VehicleDeposit = this.txtVehicleDeposit.Text;
            string VehicleInterest = this.txtVehicleInterest.Text;
            string VehiclePremium = this.txtEstimatedPremium.Text;

            //Error for empty Fields
            //----------------------------------------------------------------------------------------------------------------------------------------
            //GrossIncome and Monthly Tax
            string emptyField = "";
            if (txtGrossMonthlyIncome.Text == emptyField && txtEstimatedTax.Text == emptyField)
            {
                MessageBox.Show("Ensure all required fields are entered");
            }
            else
            //Expenses
            if (txtGroceries.Text == emptyField && txtWaterLights.Text == emptyField && txtTravel.Text == emptyField && txtPhone.Text == emptyField && txtOther.Text == emptyField)
            {
                MessageBox.Show("Ensure all required fields are entered");
            }

            if (rdbRenting.IsChecked == true)
            {
                input = 240;
                //homeloan.RentingDisplay();
            }
            else
            {
                input = Convert.ToDouble(txtNumberOfMonths.Text);
            }
            //if (rdbBuying.Checked)
            //{
            //    input = Convert.ToDouble(Text);
            //}

            if (input >= 240 || input <= 360)//Restrictions on monthly value
            {
                homeloan.setIncome(GrossMonthlyIncome);
                homeloan.addExpenses(EstimatedMonthlyTax, Groceries, WaterAndLights, Travel, Phone, OtherExpenses);
                homeloan.addBuyingProperty(PropertyPrice, TotalDeposit, InterestRate, NumberOfMonths);
                homeloan.addRent(RentalAmount);
                homeloan.addVehicle(vehicleModel, VehiclePrice, VehicleDeposit, VehicleInterest, VehiclePremium);


                if (rdbBuying.IsChecked == true)
                {
                    input = Convert.ToDouble(txtNumberOfMonths.Text);

                    if (input >= 240 && input <= 360)
                    {
                        homeloan.BuyingDisplay();
                    }

                    if (input < 240 || input > 360)//if the input is above or below the required amount display the following message
                    {
                        MessageBox.Show("Please enter Months between 240 and 360");

                    }

                    //}
                    //else if (rdbRenting.Checked)
                    //{
                    //    homeloan.RentingDisplay();
                    //}


                }

                //--> from here
                //rdb buttons: renting property & not buying a vehicle
                if (rdbRenting.IsChecked == true && rdbNo.IsChecked == true)
                {
                    homeloan.RentingDisplay();
                }
                //rdb buttons: renting property & buying a vehicle
                else if (rdbRenting.IsChecked == true && rdbYes.IsChecked == true)
                {
                    homeloan.RentingWithVehDisplay();
                }

                if (rdbBuying.IsChecked == true && rdbNo.IsChecked == true)
                {
                    homeloan.BuyingDisplay();
                }
                else if (rdbBuying.IsChecked == true && rdbYes.IsChecked == true)
                {
                    homeloan.BuyingWithVehDisplay();
                }
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            //Clear users input 
            txtGrossMonthlyIncome.Text = "";
            txtEstimatedTax.Text = "";

            //Clear users input for expenses
            txtGroceries.Text = "";
            txtWaterLights.Text = "";
            txtTravel.Text = "";
            txtPhone.Text = "";
            txtOther.Text = "";

            //Clear users input for buying a house
            txtPropertyPrice.Text = "";
            txtTotalDeposit.Text = "";
            txtInterestRate.Text = "";
            txtNumberOfMonths.Text = "";

            //Clear users input for renting a house
            txtRentalAmount.Text = "";

            //Clear users input for a vehicle
            txtModelMake.Text = "";
            txtVehiclePrice.Text = "";
            txtVehicleDeposit.Text = "";
            txtVehicleInterest.Text = "";
            txtEstimatedPremium.Text = "";

        }
    }
}
